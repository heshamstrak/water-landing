<div class="animated-checkbox">
    <label class="m-0">
        <input type="checkbox" class="record__select" value="{{ $id }}">
        <span class="label-text"></span>
    </label>
</div>